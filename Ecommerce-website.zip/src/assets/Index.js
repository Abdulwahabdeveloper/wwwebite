import UserIcons from '../assets/usericons.png';
import heroimg from '../assets/images/hero-img.png';
import product1img from '../assets/images/arm-chair-01.jpg';
export {
    UserIcons,
    heroimg,
    product1img
}