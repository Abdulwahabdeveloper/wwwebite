import React from 'react'
import Layout from './component/Layout/layout'
import './App.css'

function App() {

  return (
    <>
     <Layout/>
    </>
  )
}

export default App
